function calculateResult() {
  const quizForm = document.getElementById('agriculture-quiz');
  const quizResult = document.getElementById('quiz-result');
  let score = 0;

  // Count the correct answers
  const answers = quizForm.querySelectorAll('input[type="radio"]:checked');
  answers.forEach(answer => {
    if (answer.value === 'right') {
      score++;
    }
  });

  // Determine the result based on the score
  let resultText = '';
  if (score === answers.length) {
    resultText = 'Congratulations! You have a strong potential for a career in agriculture.';
  } else if (score > answers.length / 2) {
    resultText = 'You have some knowledge in agriculture. Consider exploring this field further.';
  } else {
    resultText = 'Agriculture might not be the best fit for you based on your quiz answers.';
  }

  quizResult.textContent = resultText;
}
